<template>
  <v-app>
    <v-main>
      <!-- Show Auth Page or Posts View based on loggedIn status -->
      <auth-page v-if="!loggedIn" @auth-success="handleAuthSuccess" />
      <div v-else>
        <posts-view />
        <v-btn @click="openDialog">Create new post</v-btn>
        <add-post :currentUser="username" ref="addPostDialog" />
      </div>
    </v-main>
  </v-app>
</template>

<script>
import AuthPage from './components/AuthPage.vue';
import PostsView from './components/PostsView.vue';
import AddPost from './components/AddPost.vue';

export default {
  components: {
    AuthPage,
    PostsView,
    AddPost
  },
  data: () => ({
    loggedIn: false,
    username: ''
  }),
  methods: {
    handleAuthSuccess(user) {
      this.loggedIn = true;
      this.username = user.name; // Assume username is returned from the server
    },
    openDialog() {
      this.$refs.addPostDialog.showDialog = true;
    }
  }
}
</script>
