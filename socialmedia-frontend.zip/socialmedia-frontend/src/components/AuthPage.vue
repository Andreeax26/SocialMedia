<template>
    <div>
      <v-container>
        <!-- Toggle Button -->
        <v-btn @click="toggleForm">
          Switch to {{ showLogin ? 'Sign Up' : 'Login' }}
        </v-btn>
  
        <!-- Conditional Form Display -->
        <div v-if="showLogin">
          <h2>Login</h2>
          <v-form @submit.prevent="login">
            <v-text-field v-model="loginEmail" label="Email" required></v-text-field>
            <v-btn type="submit">Login</v-btn>
          </v-form>
        </div>
        <div v-else>
          <h2>Sign Up</h2>
          <v-form @submit.prevent="register">
            <v-text-field v-model="user.name" label="Name" required></v-text-field>
            <v-text-field v-model="user.email" label="Email" required></v-text-field>
            <v-btn type="submit">Sign Up</v-btn>
          </v-form>
        </div>
      </v-container>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        user: {
          name: '',
          email: ''
        },
        loginEmail: '',
        showLogin: true, // Controls which form to show
      };
    },
    methods: {
      toggleForm() {
        this.showLogin = !this.showLogin; // Toggle between Login and Sign Up
      },
      async login() {
        try {
          // Simulate API call for login
          const response = await this.$http.post('/login', { email: this.loginEmail });
          this.$emit('auth-success', response.data); // Notify parent component
        } catch (error) {
          console.error('Login failed:', error);
        }
      },
      async register() {
        try {
          // Simulate API call for registration
          const response = await this.$http.post('/register', this.user);
          this.$emit('auth-success', response.data); // Notify parent component
        } catch (error) {
          console.error('Registration failed:', error);
        }
      }
    }
  }
  </script>
  